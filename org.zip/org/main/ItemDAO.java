package org.main;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import org.model.Item;
import org.util.DBFactory;

public class ItemDAO {
	public static void delete(Integer id) throws ClassNotFoundException, SQLException {
		Connection con = DBFactory.getConn();
		Statement stmt = con.createStatement();
		String query = "delete from item_tbl where id = " + id;
		int count = stmt.executeUpdate(query);
		if(count > 0)
			System.out.println("Item removed");
		else
			System.out.println("Item Not found with this id #" + id);
		stmt.close();
	}
	public static void insert(Item item) throws ClassNotFoundException, SQLException {
		Connection con = DBFactory.getConn();
		Statement stmt = con.createStatement();
		String query = "insert into item_tbl values(" + item.getId() + ", '" + item.getName() + "', " + item.getPrice()
				+")";
		stmt.executeUpdate(query);
		System.out.println("Values Inserted");
		stmt.close();
	}
}



