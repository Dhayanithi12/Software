package org.main;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.model.User;
import org.util.DBFactory;

public class Authentication {
	public static boolean check(User user) throws ClassNotFoundException, SQLException {
		boolean status = false;
		Connection con = DBFactory.getConn();
		Statement stmt = con.createStatement();
		ResultSet rs = stmt.executeQuery("select * from user_details" 
				+ " where username='" + user.getUsername()
				+ "' and password='" + user.getPassword() + "'");
		if(rs.next()) {
			status = true;
		}
		rs.close();
		stmt.close();
		return status;
	}
}
