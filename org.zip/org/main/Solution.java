package org.main;

import java.io.BufferedReader;
import java.io.Console;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;

import org.model.Item;
import org.model.User;

public class Solution {

	public static void main(String[] args) throws IOException {
		BufferedReader cons = new BufferedReader(new InputStreamReader(System.in));
		System.out.print("Username :");
		String username = cons.readLine();
		System.out.print("Password :");
		String password = cons.readLine();
		User user = new User(username, password);
		try {
			if (Authentication.check(user)) {
				System.out.println("Login Success");
				boolean flag = false;
				while (true) {
					System.out.print("1.Create 2.Retrieve 3.Update 4.Delete 5.View All\n Choice:");
					switch (Integer.parseInt(cons.readLine())) {
					case 1:
						Item item = new Item();
						item.setId(Integer.parseInt(cons.readLine()));
						item.setName(cons.readLine());
						item.setPrice(Double.parseDouble(cons.readLine()));
						ItemDAO.insert(item);
						break;
					case 4:
						Integer id = Integer.parseInt(cons.readLine());
						ItemDAO.delete(id);
						break;
					default:
						flag = true;
						break;
					}
					if(flag)
						break;
				}
			} else {
				System.out.println("Invalid Login Details");
			}
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

}
